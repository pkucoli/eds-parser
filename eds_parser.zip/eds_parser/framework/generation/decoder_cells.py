# -*- coding: utf-8 -*-

from ..common.dataclass_options import BranchSelect
from .models.copynet import CopyNetCell
from .models.pointer_generator import PointerGeneratorCell
from .models.simple import SimpleCell


class DecoderCellOptions(BranchSelect):
    type = 'pointer_generator'
    branches = {
        'pointer_generator': PointerGeneratorCell,
        'copynet': CopyNetCell,
        'simple': SimpleCell
    }
