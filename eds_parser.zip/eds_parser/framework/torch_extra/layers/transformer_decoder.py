# -*- coding: utf-8 -*-

import math

import torch
import torch.nn as nn
import torch.nn.init as init

from ...common.dataclass_options import OptionsBase, argfield
from ..activations import get_activation
from .dropout import FeatureDropout
from .transformer_encoder import MultiHeadAttention, PositionwiseFeedForward

# TODO


class TransformerDecoderLayer(nn.Module):
    def __init__(self, num_heads, d_model, d_k, d_v, d_ff, activation,
                 residual_dropout=0.1, attention_dropout=0.1, output_dropout=0.1):
        super().__init__()

        self.self_attention = \
            MultiHeadAttention(num_heads, d_model, d_k, d_v,
                               attention_dropout=attention_dropout)

        self.context_attention = \
            MultiHeadAttention(num_heads, d_model, d_k, d_v,
                               attention_dropout=attention_dropout)

        self.feedforward = \
            PositionwiseFeedForward(d_model, d_ff, get_activation(activation),
                                    output_dropout=output_dropout,
                                    residual_dropout=residual_dropout,
                                    use_norm_after_input=True)

        self.layer_norm1 = nn.LayerNorm(d_model, eps=1e-6)
        self.layer_norm2 = nn.LayerNorm(d_model, eps=1e-6)

        self.residual_dropout = FeatureDropout(residual_dropout)

    def forward(self, inputs, memory_bank, context_mask, self_mask):
        """
        Args:
            inputs (FloatTensor): ``(batch_size, 1, d_model)``
            memory_bank (FloatTensor): ``(batch_size, source_length, d_model)``
            context_mask (ByteTensor): ``(batch_size, 1, source_length)``
            self_mask (ByteTensor): ``(batch_size, 1, 1)``
        Returns:
            (FloatTensor, FloatTensor):
            * output ``(batch_size, 1, d_model)``
            * attention ``(batch_size, 1, source_length)``
        """

        # if step is None:
        #     target_length = target_pad_mask.size(-1)
        #     future_mask = torch.ones([target_length, target_length],
        #                              device=target_pad_mask.device,
        #                              dtype=torch.uint8)

        #     # BoolTensor was introduced in pytorch 1.2
        #     future_mask = future_mask.triu_(1).unsqueeze(0) != 0

        #     decoder_mask = (target_pad_mask + future_mask) > 0

        inputs_norm = self.layer_norm1(inputs)
        query, _ = self.self_attention(inputs_norm, inputs_norm, inputs_norm,
                                       mask=self_mask)

        query = self.residual_dropout(query) + inputs

        query_norm = self.layer_norm2(query)
        context, attention = self.context_attention(memory_bank, memory_bank, query_norm,
                                                    mask=context_mask)

        output = self.feed_forward(self.residual_dropout(context) + query)

        return output, attention


class TransformerDecoder(nn.Module):
    class Options(OptionsBase):
        num_layers: int = 2
        num_heads: int = 8
        d_kv: int = 32
        d_ff: int = 1024

        output_dropout: float = 0.1
        residual_dropout: float = 0.1
        attention_dropout: float = 0.1

        timing_dropout: float = 0.0
        timing_method: str = argfield('embedding', choices=['embedding', 'sinusoidal'])
        use_timing_layer_norm: bool = False

        max_length: int = 512

        activation: str = 'leaky_relu/0.1'

    def __init__(self, options: Options, input_size, target_vocab):
        super().__init__()

        d_model = input_size
        d_k = d_v = options.d_kv
        d_ff = options.d_ff

        self.layers = nn.Sequential(
            TransformerDecoderLayer(options.num_heads, d_model, d_k, d_v, d_ff,
                                    activation=options.activation,
                                    residual_dropout=options.residual_dropout,
                                    attention_dropout=options.attention_dropout,
                                    output_dropout=options.output_dropout)
            for _ in range(options.num_layers)
        )

        max_length = options.max_length

        self.timing_dropout = FeatureDropout(options.timing_dropout)

        position_size = input_size
        timing_method = options.timing_method
        if timing_method == 'embedding':  # Learned embeddings
            self.position_table = nn.Parameter(torch.FloatTensor(max_length, position_size))
            init.normal_(self.position_table)
        else:
            assert timing_method == 'sinusoidal'

            position_table = torch.zeros(max_length, position_size)

            position = torch.arange(0, max_length, dtype=torch.float).view(-1, 1)
            div_term = torch.exp((torch.arange(0, input_size, 2, dtype=torch.float) *
                                  -(math.log(10000.0) / input_size)))
            position_table[:, 0::2] = torch.sin(position * div_term)
            position_table[:, 1::2] = torch.cos(position * div_term)

            self.position_table = nn.Parameter(position_table, requires_grad=False)

        self.timing_layer_norm = nn.LayerNorm(position_size, eps=1e-6)

    def forward(self, decoder_state, output_word_t_1, **_kwargs):
        pass
