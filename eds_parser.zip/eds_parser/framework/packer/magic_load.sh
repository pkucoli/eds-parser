#!/usr/bin/env bash
CODE_LENGTH=%d
DATA_LENGTH=%d

export RUN_IN_PACKED_MODE=ON

if [ -z "$PYTHON" ];then
    PYTHON=$(command -v python3)
fi

SCRIPT_FILE=$(mktemp)

cat > "$SCRIPT_FILE" <<__MAGIC_LOADER_{0}__
{1}
__MAGIC_LOADER_{0}__

"$PYTHON" "$SCRIPT_FILE" "$0" $CODE_LENGTH $DATA_LENGTH "$@"

RETVAL=$?

rm "$SCRIPT_FILE"

exit $RETVAL
