# -*- coding: utf-8 -*-

import torch
from crf import CRF as CRF_standard

from framework.torch_extra.layers.crf import CRF, sequence_mask

crf = CRF(100)
crf_s = CRF_standard(100)

crf_s.load_state_dict(crf.state_dict())

emissions = torch.randn(20, 10, 100)
lengths = torch.randint(19, (10,)) + 1
tags = torch.randint(99, (20, 10))

mask = sequence_mask(lengths, max_length=20, batch_first=False)


a = crf_s(emissions, tags, mask, summed=False)
b = crf(emissions, tags, lengths, batch_first=False)
c = crf_s.decode(emissions, mask)
d = crf.viterbi_decode(emissions, lengths, batch_first=False)
