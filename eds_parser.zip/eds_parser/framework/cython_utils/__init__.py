# -*- coding: utf-8 -*-

import os
import pyximport

pyximport.install(build_dir=os.path.join(os.path.dirname(__file__), '.cython-cache'))

from .lcs import longest_common_subsequence  # noqa
