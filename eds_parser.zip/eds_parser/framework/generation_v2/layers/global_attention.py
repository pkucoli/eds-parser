# -*- coding: utf-8 -*-

"""Global attention modules (Luong / Bahdanau)"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from ...torch_extra.utils import sequence_mask


class GlobalAttention(nn.Module):
    r"""
    @see https://github.com/OpenNMT/OpenNMT-py/blob/master/onmt/modules/global_attention.py
    * Luong Attention (dot, general):
       * dot: :math:`\text{score}(H_j,q) = H_j^T q`
       * general: :math:`\text{score}(H_j, q) = H_j^T W_a q`
    * Bahdanau Attention (mlp):
       * :math:`\text{score}(H_j, q) = v_a^T \text{tanh}(W_a q + U_a h_j)`
    Args:
       attention_size (int): dimensionality of query and key
       coverage (bool): use coverage term
       attention_type (str): type of attention to use, options [dot, general, mlp]
    """

    def __init__(self, attention_size, attention_type, use_coverage=False):
        super().__init__()

        self.attention_type = attention_type
        assert attention_type in ['dot', 'general', 'mlp']

        if self.attention_type == 'general':
            self.linear_in = nn.Linear(attention_size, attention_size, bias=False)
        elif self.attention_type == 'mlp':
            self.linear_context = nn.Linear(attention_size, attention_size, bias=False)
            self.linear_query = nn.Linear(attention_size, attention_size, bias=True)
            self.v = nn.Linear(attention_size, 1, bias=False)

        # mlp wants it with bias
        out_bias = self.attention_type == 'mlp'
        self.linear_out = nn.Linear(attention_size * 2, attention_size, bias=out_bias)

        if use_coverage:
            self.linear_coverage = nn.Linear(1, attention_size, bias=False)

    def score(self, h_t, h_s):
        """
        Args:
          h_t (FloatTensor): sequence of queries ``(batch, target_length, attention_size)``
          h_s (FloatTensor): sequence of sources ``(batch, source_length, attention_size)``
        Returns:
          FloatTensor: raw attention scores (unnormalized) for each source index
            ``(batch, target_length, source_length)``
        """

        # Check input sizes
        source_batch, source_length, source_size = h_s.size()
        target_batch, target_length, target_size = h_t.size()

        assert source_batch == target_batch
        assert source_size == target_size == self.attention_size

        attention_type = self.attention_type
        if attention_type in ['general', 'dot']:
            if attention_type == 'general':
                h_t = self.linear_in(h_t)

            h_s_ = h_s.transpose(1, 2)
            # (batch, target_length, *) x (batch, *, source_length)
            # --> (batch, target_length, source_length)
            return torch.bmm(h_t, h_s_)

        # (batch, target_length, 1, attention_size)
        wq = self.linear_query(h_t).unsqueeze(2)
        # (batch, target_length, source_length, attention_size)
        wq = wq.expand(-1, -1, source_length, -1)

        # (batch, 1, source_length, attention_size)
        uh = self.linear_context(h_s.contiguous()).unsqueeze(1)
        # (batch, target_length, source_length, attention_size)
        uh = uh.expand(-1, target_length, -1, -1)

        wquh = torch.tanh(wq + uh)

        return self.v(wquh).squeeze(-1)

    def forward(self, source, memory_bank, memory_mask=None, coverage=None):
        """
        Args:
          source (FloatTensor): query vectors ``(batch, target_length, attention_size)``
          memory_bank (FloatTensor): source vectors ``(batch, source_length, attention_size)``
          memory_mask (ByteTensor): the source context mask ``(batch, source_length)``
          coverage (FloatTensor): the coverage vector ``(batch, source_length)``
        Returns:
          (FloatTensor, FloatTensor):
          * Computed vector ``(target_length, batch, attention_size)``
          * Attention distribtutions for each query
            ``(target_length, batch, source_length)``
        """

        # one step input
        one_step = (source.dim() == 2)
        if one_step:
            source = source.unsqueeze(1)

        batch_size, source_length, attention_size = memory_bank.size()

        assert batch_size == source.size(0)
        assert attention_size == source.size(2) == self.attention_size

        if coverage is not None:
            assert batch_size == coverage.size(0)
            assert source_length == coverage.size(1)

            # NOTE: ??? here we use +=
            memory_bank += self.linear_coverage(coverage.unsqueeze(-1))
            memory_bank = torch.tanh(memory_bank)

        # compute attention scores, as in Luong et al.
        align = self.score(source, memory_bank)  # (batch_size, target_length, source_length)

        if memory_mask is not None:
            # make it broadcastable. (batch_size, 1, source_length)
            mask = memory_mask.unsqueeze(1)
            align.masked_fill_(~mask, -float('inf'))

        # Softmax to normalize attention weights. (batch_size, target_length, source_length)
        align_vectors = F.softmax(align.view(-1, source_length), -1)
        align_vectors = align_vectors.view_as(align)

        # each context vector is the weighted average over all the source hidden states
        context = torch.bmm(align_vectors, memory_bank)

        # (batch_size, target_length, attention_size)
        attention = self.linear_out(torch.cat([context, source], dim=2))

        if self.attention_type in ['general', 'dot']:
            attention = torch.tanh(attention)

        if one_step:
            attention = attention.squeeze(1)
            align_vectors = align_vectors.squeeze(1)
        else:
            attention = attention.transpose(0, 1).contiguous()
            align_vectors = align_vectors.transpose(0, 1).contiguous()

        # (target_length, batch_size, *)
        return attention, align_vectors
