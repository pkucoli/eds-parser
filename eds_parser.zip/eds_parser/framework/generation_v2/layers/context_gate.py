# -*- coding: utf-8 -*-

""" ContextGate module
@see https://github.com/OpenNMT/OpenNMT-py/blob/master/onmt/modules/gate.py"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def get_context_gate(gate_type, embeddings_size, decoder_size, attention_size, output_size):
    gate_types = {'source': SourceContextGate,
                  'target': TargetContextGate,
                  'both': BothContextGate}

    gate = gate_types.get(gate_type)
    assert gate is not None, f'Not valid ContextGate type: {gate_type}'
    return gate(embeddings_size, decoder_size, attention_size, output_size)


class ContextGate(nn.Module):
    """
    Context gate is a decoder module that takes as input the previous word
    embedding, the current decoder state and the attention state, and
    produces a gate.
    The gate can be used to select the input from the target side context
    (decoder state), from the source context (attention state) or both.
    """

    def __init__(self, embeddings_size, decoder_size, attention_size, output_size):
        super().__init__()

        input_size = embeddings_size + decoder_size + attention_size

        self.gate = nn.Linear(input_size, output_size, bias=True)

        self.source_proj = nn.Linear(attention_size, output_size)
        self.target_proj = nn.Linear(embeddings_size + decoder_size, output_size)

    def gate(self, previous_emb, decoder_state, attention_state):
        inputs = torch.cat([previous_emb, decoder_state, attention_state], dim=1)
        z = F.sigmoid(self.gate(inputs))

        proj_source = self.source_proj(attention_state)
        proj_target = self.target_proj(torch.cat([previous_emb, decoder_state], dim=1))

        return z, proj_source, proj_target


class SourceContextGate(ContextGate):
    """Apply the context gate only to the source context"""

    def forward(self, previous_emb, decoder_state, attention_state):
        z, source, target = self.gate(previous_emb, decoder_state, attention_state)
        return torch.tanh(target + z * source)


class TargetContextGate(ContextGate):
    """Apply the context gate only to the target context"""

    def forward(self, previous_emb, decoder_state, attention_state):
        z, source, target = self.gate(previous_emb, decoder_state, attention_state)
        return torch.tanh(z * target + source)


class BothContextGate(ContextGate):
    """Apply the context gate to both contexts"""

    def forward(self, previous_emb, decoder_state, attention_state):
        z, source, target = self.gate(previous_emb, decoder_state, attention_state)
        return torch.tanh((1. - z) * target + z * source)
