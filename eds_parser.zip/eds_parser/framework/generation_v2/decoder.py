# -*- coding: utf-8 -*-

import torch
import torch.nn as nn

from ..common.dataclass_options import OptionsBase, argfield
from ..common.utils import DotDict
from .layers.context_gate import get_context_gate
from .layers.global_attention import GlobalAttention
from .layers.stacked_rnn import StackedGRU, StackedLSTM


class RNNDecoderBase(nn.Module):
    class Options(OptionsBase):
        rnn: str = argfield('GRU', choices=['GRU', 'LSTM'])
        attention: str = argfield('general', choices=['general', 'dot', 'mlp'])

        num_layers: int = 2
        hidden_size: int = 512

        use_coverage: bool = False
        context_gate: str = 'none'

        copy_attention: str = argfield('none', choices=['general', 'dot', 'mlp'])
        reuse_copy_attention: bool = False

        dropout: float = 0.3

    def __init__(self, options: Options, embeddings):
        super().__init__()

        self.num_layers = options.num_layers
        self.hidden_size = hidden_size = options.hidden_size
        self.embeddings = embeddings
        self.dropout = nn.Dropout(options.dropout)

        # Decoder state
        self.state = DotDict()

        # Build the RNN.
        self.rnn = self._build_rnn(options)

        # Set up the context gate.
        self.context_gate = None
        if options.context_gate != 'none':
            self.context_gate = get_context_gate(options.context_gate,
                                                 self._input_size,
                                                 hidden_size, hidden_size, hidden_size)

        # Set up the standard attention.
        self._use_coverage = options.use_coverage
        self.attention = GlobalAttention(hidden_size,
                                         attention_type=options.attention,
                                         use_coverage=options.use_coverage)

        self._reuse_copy_attention = options.reuse_copy_attention
        self.copy_attention = None

        copy_attention = options.copy_attention
        if self._reuse_copy_attention:
            assert copy_attention == 'none'
        elif copy_attention != 'none':
            self.copy_attention = GlobalAttention(hidden_size, attention_type=copy_attention)

    def init_state(self, source, memory_bank, encoder_final):
        """Initialize decoder state with last state of the encoder."""

        def _fix_enc_hidden(hidden):
            # The encoder hidden is  (layers*directions) x batch x dim.
            # We need to convert it to layers x batch x (directions*dim).
            if self.bidirectional_encoder:
                hidden = torch.cat([hidden[0:hidden.size(0):2],
                                    hidden[1:hidden.size(0):2]], 2)
            return hidden

        if isinstance(encoder_final, tuple):  # LSTM
            self.state["hidden"] = tuple(_fix_enc_hidden(enc_hid)
                                         for enc_hid in encoder_final)
        else:  # GRU
            self.state["hidden"] = (_fix_enc_hidden(encoder_final), )

        # Init the input feed.
        batch_size = self.state["hidden"][0].size(1)
        h_size = (batch_size, self.hidden_size)
        self.state['input_feed'] = \
            self.state['hidden'][0].data.new(*h_size).zero_().unsqueeze(0)
        self.state['coverage'] = None

    def map_state(self, fn):
        state = self.state

        state.hidden = tuple(fn(h, 1) for h in self.state.hidden)
        state.input_feed = fn(state.input_feed, 1)

        coverage = self.state.coverage
        if self._use_coverage and coverage is not None:
            self.state.coverage = fn(coverage, 1)

    def detach_state(self):
        state = self.state
        state.hidden = tuple(h.detach() for h in state.hidden)
        state.input_feed = state.input_feed.detach()

    def forward(self, targets, memory_bank, memory_mask=None, step=None):
        """
        Args:
            targets (LongTensor): sequences of padded tokens
                 ``(target_length, batch)``.
            memory_bank (FloatTensor): vectors from the encoder
                 ``(batch, source_length, hidden_size)``.
            memory_mask (ByteTensor): the padded source mask ``(batch, source_length)``.

        Returns:
            (FloatTensor, dict[str, FloatTensor]):

            * decoder_outputs: output from the decoder (after attention)
              ``(target_length, batch, hidden_size)``.
            * attentions: distribution over src at each targets
              ``(target_length, batch, source_length)``.
        """

        decoder_state, decoder_outputs, attentions = \
            self._run_forward_pass(targets, memory_bank, memory_mask=memory_mask)

        # Update the state with the result.
        if not isinstance(decoder_state, tuple):
            decoder_state = (decoder_state,)

        self.state.hidden = decoder_state
        self.state.input_feed = decoder_outputs[-1].unsqueeze(0)  # last output state

        coverage = attentions.get('coverage')
        if coverage is not None:
            coverage = coverage[-1].unsqueeze(0)
        self.state.coverage = coverage

        # TODO: removal
        # Concatenates sequence of tensors along a new dimension.
        # NOTE: v0.3 to 0.4: decoder_outputs / attentions[*] may not be list
        #       (in particular in case of SRU) it was not raising error in 0.3
        #       since stack(Variable) was allowed.
        #       In 0.4, SRU returns a tensor that shouldn't be stacke
        # if type(decoder_outputs) == list:
        #     decoder_outputs = torch.stack(decoder_outputs)

        #     for k in attentions:
        #         if type(attentions[k]) == list:
        #             attentions[k] = torch.stack(attentions[k])

        return decoder_outputs, attentions


class InputFeedRNNDecoder(RNNDecoderBase):
    """Input feeding based decoder."""

    def _run_forward_pass(self, targets, memory_bank, memory_mask=None):
        """
        Private helper for running the specific RNN forward pass.
        Must be overriden by all subclasses.
        Args:
            targets (LongTensor): a sequence of input tokens tensors
                ``(target_length, batch, nfeats)``.
            memory_bank (FloatTensor): output(tensor sequence) from the
                encoder RNN of size ``(batch, source_len, hidden_size)``.
            memory_mask (ByteTensor): the source memory_bank mask.
        Returns:
            (Tensor, List[FloatTensor], Dict[str, List[FloatTensor]):
            * decoder_state: final hidden state from the decoder.
            * decocder_outputs: an array of output of every time
              step from the decoder.
            * attentions: a dictionary of different
              type of attention Tensor array of every time
              step from the decoder.
        """
        input_feed = self.state.input_feed.squeeze(0)

        assert targets.size(1) == input_feed.size(0)

        decoder_outputs = []

        attentions = {'std': []}
        if self.copy_attention is not None or self._reuse_copy_attention:
            attentions['copy'] = []
        if self._use_coverage:
            attentions['coverage'] = []

        inputs = self.embeddings(targets)
        assert inputs.dim() == 3  # target_length x batch x embedding_dim

        decoder_state = self.state.hidden
        coverage = self.state.coverage
        if coverage is not None:
            coverage = coverage.squeeze(0)

        # Input feed concatenates hidden state with input at every time step.
        for input_t in inputs.split(1):
            decoder_input = torch.cat([input_t.squeeze(0), input_feed], dim=1)
            rnn_output, decoder_state = self.rnn(decoder_input, decoder_state)
            decoder_output, prob_attn = \
                self.attention(rnn_output, memory_bank, memory_mask=memory_mask)

            attentions['std'].append(prob_attn)
            if self.context_gate is not None:
                decoder_output = self.context_gate(decoder_input, rnn_output, decoder_output)

            decoder_output = self.dropout(decoder_output)
            input_feed = decoder_output

            decoder_outputs.append(decoder_output)

            # Update the coverage attention.
            if self._use_coverage:
                coverage = prob_attn if coverage is None else prob_attn + coverage
                attentions['coverage'].append(coverage)

            if self.copy_attention is not None:
                _, copy_attn = \
                    self.copy_attention(decoder_output, memory_bank, memory_mask=memory_mask)
                attentions['copy'].append(copy_attn)
            elif self._reuse_copy_attn:
                attentions['copy'] = attentions['std']

        return decoder_state, decoder_outputs, attentions

    def _build_rnn(self, options):
        stacked_cell = StackedLSTM if options.rnn == 'LSTM' else StackedGRU
        return stacked_cell(num_layers=options.num_layers,
                            input_size=self._input_size,
                            rnn_size=options.hidden_size,
                            dropout=options.dropout)

    @property
    def _input_size(self):
        """Using input feed by concatenating input with attention vectors."""
        return self.embeddings.output_size + self.hidden_size
