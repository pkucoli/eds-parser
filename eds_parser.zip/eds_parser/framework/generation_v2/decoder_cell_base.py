# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..common.dataclass_options import OptionsBase, argfield
from ..common.utils import DotDict
from ..torch_extra.utils import clip_and_renormalize
from .layers.context_gate import get_context_gate
from .layers.global_attention import GlobalAttention
from .layers.stacked_rnn import StackedGRU, StackedLSTM


class DecoderCellBase(nn.Module):
    class Options(OptionsBase):
        rnn: str = argfield('GRU', choices=['GRU', 'LSTM'])
        attention: str = argfield('general', choices=['general', 'dot', 'mlp'])

        num_layers: int = 2
        hidden_size: int = 512

        use_coverage: bool = False
        context_gate: str = 'none'

        copy_attention: str = argfield('none', choices=['general', 'dot', 'mlp'])
        reuse_copy_attention: bool = False

        dropout: float = 0.3

    def __init__(self, options: Options, input_size, embeddings, extra_keys=()):
        super().__init__()

        self.extra_keys = extra_keys

        self.input_size = input_size
        self.num_words = embeddings.num_embeddings
        self.hidden_size = hidden_size = options.hidden_size

        assert input_size == hidden_size, \
            'encoder input size should equal to hidden size'

        self.state = DotDict()

        # Build the RNN.
        self.rnn_type = options.rnn
        self.rnn = self._build_rnn(options)

        self.embeddings = embeddings
        self.dropout = nn.Dropout(options.dropout)

        # Set up the context gate.
        self.context_gate = None
        if options.context_gate != 'none':
            self.context_gate = get_context_gate(options.context_gate,
                                                 self._input_size,
                                                 hidden_size, hidden_size, hidden_size)

        # Set up the standard attention.
        self._use_coverage = options.use_coverage
        self.attention = GlobalAttention(hidden_size,
                                         attention_type=options.attention,
                                         use_coverage=options.use_coverage)

        self._reuse_copy_attention = options.reuse_copy_attention
        self.copy_attention = None

        copy_attention = options.copy_attention
        if self._reuse_copy_attention:
            assert copy_attention == 'none'
        elif copy_attention != 'none':
            self.copy_attention = GlobalAttention(hidden_size, attention_type=copy_attention)

    def init_state(self, source, memory_bank, encoder_final):
        """Initialize decoder state with last state of the encoder."""

        def _fix_enc_hidden(hidden):
            # The encoder hidden is  (layers*directions) x batch x dim.
            # We need to convert it to layers x batch x (directions*dim).
            if self.bidirectional_encoder:
                hidden = torch.cat([hidden[0:hidden.size(0):2],
                                    hidden[1:hidden.size(0):2]], 2)
            return hidden

        if isinstance(encoder_final, tuple):  # LSTM
            self.state["hidden"] = tuple(_fix_enc_hidden(enc_hid)
                                         for enc_hid in encoder_final)
        else:  # GRU
            self.state["hidden"] = (_fix_enc_hidden(encoder_final), )

        # Init the input feed.
        batch_size = self.state["hidden"][0].size(1)
        h_size = (batch_size, self.hidden_size)
        self.state['input_feed'] = \
            self.state['hidden'][0].data.new(*h_size).zero_().unsqueeze(0)
        self.state['coverage'] = None

    def get_init_state(self, encoder_outputs, encoder_hidden):
        device = encoder_hidden.device

        if self.project_h is not None:
            state_h = self.project_h(encoder_hidden)
            if self.project_c is not None:
                state_c = self.project_c(encoder_hidden)
        else:
            tensor = torch.zeros(encoder_hidden.size(0), self.hidden_size, device=device)
            state_h = state_c = tensor

        if self.rnn_cell is nn.GRUCell:
            state_0 = state_h
        else:
            state_0 = state_h, state_c

        context_0 = torch.zeros(encoder_hidden.size(0), self.input_size, device=device)
        coverage_0 = None
        if self.options.use_coverage:
            coverage_0 = torch.zeros(*encoder_outputs.shape[:-1], device=device)

        return state_0, context_0, coverage_0

    def compute_loss(self, attn_dist, vocab_dist, old_coverage, target_words):
        loss = F.nll_loss(vocab_dist.log(), target_words, reduction='none')
        if self.options.use_coverage:
            coverage_loss = torch.min(old_coverage, attn_dist).sum(dim=1)
            loss += coverage_loss * self.options.coverage_loss_weight

        # TODO: masking maybe redundant
        return loss * (target_words != -100).float()
