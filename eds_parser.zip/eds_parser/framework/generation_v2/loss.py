# -*- coding: utf-8 -*-

from abc import abstractmethod

import torch
import torch.nn as nn
import torch.nn.functional as F


class LossComputeBase(nn.Module):
    """
    Class for managing efficient loss computation. Handles
    sharding next step predictions and accumulating multiple
    loss computations
    Args:
        generator (:obj:`nn.Module`) :
             module that maps the output of the decoder to a
             distribution over the targets vocabulary.
        target_vocab (:obj:`Vocabulary`) :
             torchtext vocab object representing the targets output
        normalzation (str): normalize by "sentences" or "tokens"
    """

    def __init__(self, criterion, generator):
        super().__init__()

        self.criterion = criterion
        self.generator = generator

    @property
    def ignore_index(self):
        return self.criterion.ignore_index

    @abstractmethod
    def _compute_loss(self, batch, outputs, attentions):
        pass

    def __call__(self, batch, outputs, attentions, normalization=1.0):
        """Compute the forward loss.
        Args:
          batch (batch) : batch of labeled examples
          outputs (:obj:`FloatTensor`) :
              output of decoder model `[tgt_len x batch x hidden]`
          attentions (dict) : dictionary of attention distributions
              `[tgt_len x batch x src_len]`
          normalization: Optional normalization factor.
        Returns:
            A tuple with the loss and a :obj:`onmt.utils.Statistics` instance.
        """
        loss, stats = self._compute_loss(batch, outputs, attentions)
        return loss / float(normalization), stats

    def _stats(self, loss, scores, targets):
        """
        Args:
            loss (:obj:`FloatTensor`): the loss computed by the loss criterion.
            scores (:obj:`FloatTensor`): a score for each possible output
            targets (:obj:`FloatTensor`): true targets
        """
        predictions = scores.max(1)[1]
        non_padding = targets != self.ignore_index
        num_correct = ((predictions == targets) & non_padding).sum().item()
        num_non_padding = non_padding.sum().item()

        return {'num_non_padding': num_non_padding, 'num_correct': num_correct}


class LabelSmoothingLoss(nn.Module):
    """
    With label smoothing,
    KL-divergence between q_{smoothed ground truth prob.}(w)
    and p_{prob. computed by model}(w) is minimized.
    """

    def __init__(self, label_smoothing, num_labels, ignore_index=-100, ignore_labels=(),
                 reduction='none'):
        assert 0.0 < label_smoothing <= 1.0
        self.ignore_index = ignore_index

        super().__init__()

        smoothing_value = label_smoothing / (num_labels - len(ignore_labels))

        one_hot = torch.full((num_labels,), smoothing_value)
        for index in ignore_labels:
            one_hot[index] = 0

        self.confidence = 1.0 - label_smoothing
        self.reduction = reduction

    def forward(self, outputs, targets):
        """
        outputs (FloatTensor): batch_size x n_classes
        targets (LongTensor): batch_size
        """
        model_prob = self.one_hot.repeat(targets.size(0), 1)
        model_prob.scatter_(1, targets.unsqueeze(1), self.confidence)
        model_prob.masked_fill_((targets == self.ignore_index).unsqueeze(1), 0)

        return F.kl_div(outputs, model_prob, reduction=self.reduction)


class NMTLossCompute(LossComputeBase):
    """
    Standard NMT Loss Computation.
    """

    def __init__(self, criterion, generator, normalization='sentences', lambda_coverage=0.0):
        super().__init__(criterion, generator)

        self.lambda_coverage = lambda_coverage
        self.reduction = 'none' if normalization != 'sentences' else 'sum'

    def _compute_loss(self, batch, outputs, attentions):
        scores = self.generator(outputs.view(-1, outputs.size(-1)))
        ground_truth = batch.decoder_targets.view(-1)

        loss = self.criterion(scores, ground_truth, reduction=self.reduction)

        if self.lambda_coverage != 0.0:
            coverage_loss = \
                self._compute_coverage_loss(attentions.get('std'), attentions.get('coverage'))
            loss += coverage_loss

        stats = self._stats(loss.clone(), scores, ground_truth)

        if loss.dim() != 0:
            loss = loss.sum()
            pass

        return loss, stats

    def _compute_coverage_loss(self, std_attention, coverage_attention):
        coverage_loss = torch.min(std_attention, coverage_attention)
        coverage_loss *= self.lambda_coverage
        return coverage_loss
